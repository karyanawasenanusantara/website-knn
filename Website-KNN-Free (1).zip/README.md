# WEBSITE PT KARYA NAWASENA NUSANTARA

Website company profile satu halaman, dibuat dari materi Company Profile KNN.

## Struktur
- index.html   = halaman utama
- style.css    = desain
- script.js    = menu mobile + efek header
- assets/      = logo dan gambar visual

## Cara melihat website di komputer
1. Extract ZIP ini.
2. Buka folder hasil extract.
3. Double-click `index.html`.
4. Website langsung terbuka di browser.

Tidak perlu install software untuk sekadar melihatnya.

## Cara meng-online-kan GRATIS
Pilihan mudah: GitHub Pages.

1. Buat akun GitHub di https://github.com/
2. Buat repository baru, misalnya `website-knn`.
3. Upload `index.html`, `style.css`, `script.js`, dan folder `assets`.
4. Masuk ke Settings → Pages.
5. Pada Source pilih `Deploy from a branch`.
6. Pilih branch `main` dan folder `/root`.
7. Save.
8. GitHub akan memberikan alamat website gratis.

## Catatan
- Website ini tidak memakai backend/database.
- Tombol WhatsApp langsung mengarah ke nomor KNN.
- Email menggunakan mailto ke alamat KNN.
- Jika nanti ingin domain profesional seperti `karyanawasena.co.id`, domain perlu dibeli terpisah.
- Isi website sengaja mengikuti materi Company Profile yang diberikan; informasi yang belum ada (misalnya alamat kantor lengkap, daftar klien, nomor telepon kantor, sertifikasi) tidak saya tambahkan sebagai fakta.

## Sebelum dipublikasikan
Sebaiknya cek:
- nomor WhatsApp
- email
- logo resolusi tinggi
- foto perusahaan
- alamat lengkap jika ingin ditampilkan
- legalitas/sertifikasi jika memang ingin dimasukkan
